import java.util.Scanner;

public class InsertElementArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] arr = new int[100];

        for (int i = 0; i < n; i++)
            arr[i] = sc.nextInt();

        int pos = sc.nextInt();
        int value = sc.nextInt();

        for (int i = n; i >= pos; i--)
            arr[i] = arr[i - 1];

        arr[pos - 1] = value;
        n++;

        for (int i = 0; i < n; i++)
            System.out.print(arr[i] + " ");
    }
}